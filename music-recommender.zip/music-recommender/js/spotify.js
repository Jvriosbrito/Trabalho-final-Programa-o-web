// js/spotify.js
// Helpers PKCE + fluxo de autenticação Spotify (SPA frontend).
// IMPORTANTE: substitua seu SPOTIFY_CLIENT_ID abaixo.

const SPOTIFY_CLIENT_ID = '2612c4765dde4f42a6bf7f49185a39c9';

const EXPLICIT_REDIRECT_URI = 'http://127.0.0.1:5500'; // forced fixed value (use 127.0.0.1 as requested)
const REDIRECT_URI = EXPLICIT_REDIRECT_URI || (window.location.origin + '/');
// debug útil: mostra no console o REDIRECT_URI exato que será enviado ao Spotify
console.log('Spotify REDIRECT_URI =', REDIRECT_URI);
const SCOPES = 'user-read-private user-read-email playlist-modify-public playlist-modify-private';

function base64UrlEncode(buffer) {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
async function sha256(plain) {
  const encoder = new TextEncoder();
  const data = encoder.encode(plain);
  const hash = await crypto.subtle.digest('SHA-256', data);
  return hash;
}
function randomString(length = 64) {
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return Array.from(array).map(b => ('0' + b.toString(16)).slice(-2)).join('').slice(0, length);
}

async function generateCodeChallenge(verifier) {
  const hashed = await sha256(verifier);
  return base64UrlEncode(hashed);
}

async function startSpotifyAuth() {
  if (!SPOTIFY_CLIENT_ID || SPOTIFY_CLIENT_ID.includes('<COLOQUE')) {
    alert('Coloque seu SPOTIFY_CLIENT_ID em js/spotify.js antes de iniciar o fluxo.');
    return;
  }

  const codeVerifier = base64UrlEncode(crypto.getRandomValues(new Uint8Array(96)));
  sessionStorage.setItem('sp_code_verifier', codeVerifier);

  const codeChallenge = await generateCodeChallenge(codeVerifier);
  const state = Math.random().toString(36).slice(2);
  sessionStorage.setItem('sp_auth_state', state);

  const params = new URLSearchParams({
    client_id: SPOTIFY_CLIENT_ID,
    response_type: 'code',
    redirect_uri: REDIRECT_URI,
    code_challenge_method: 'S256',
    code_challenge: codeChallenge,
    state,
    scope: SCOPES
  });

  window.location.href = `https://accounts.spotify.com/authorize?${params.toString()}`;
}

async function exchangeCodeForToken() {
  try {
    const url = new URL(window.location.href);
    const code = url.searchParams.get('code');
    const state = url.searchParams.get('state');
    const error = url.searchParams.get('error');
    if (error) {
      console.warn('Erro de autenticação Spotify na URL:', error);
      return null;
    }
    if (!code) return null;
    const savedState = sessionStorage.getItem('sp_auth_state');
    if (state !== savedState) {
      console.warn('PKCE: discrepância no state');
      return null;
    }

    const codeVerifier = sessionStorage.getItem('sp_code_verifier');
    if (!codeVerifier) {
      console.error('Nenhum code_verifier encontrado em sessionStorage');
      return null;
    }

    const body = new URLSearchParams({
      grant_type: 'authorization_code',
      code,
      redirect_uri: REDIRECT_URI,
      client_id: SPOTIFY_CLIENT_ID,
      code_verifier: codeVerifier
    });

    const res = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString()
    });

    if (!res.ok) {
      const txt = await res.text();
      console.error('Falha na troca do token', res.status, txt);
      return null;
    }

    const data = await res.json();
    const now = Date.now();
    sessionStorage.setItem('sp_token', JSON.stringify({
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: now + (data.expires_in * 1000)
    }));
    scheduleRefresh(data.expires_in, data.refresh_token);
    history.replaceState({}, document.title, REDIRECT_URI);
    return data;
  } catch (err) {
    console.error('Erro em exchangeCodeForToken', err);
    return null;
  }
}

async function refreshAccessToken() {
  try {
    const stored = JSON.parse(sessionStorage.getItem('sp_token') || '{}');
    const refresh_token = stored.refresh_token;
    if (!refresh_token) return null;

    const body = new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token,
      client_id: SPOTIFY_CLIENT_ID
    });

    const res = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString()
    });

    if (!res.ok) {
      const txt = await res.text();
      console.error('Falha ao renovar token', res.status, txt);
      return null;
    }

    const data = await res.json();
    const now = Date.now();
    const newRefresh = data.refresh_token || refresh_token;
    const tokenObj = { access_token: data.access_token, refresh_token: newRefresh, expires_at: now + (data.expires_in * 1000) };
    sessionStorage.setItem('sp_token', JSON.stringify(tokenObj));
    scheduleRefresh(data.expires_in, newRefresh);
    return tokenObj;
  } catch (err) {
    console.error('Erro em refreshAccessToken', err);
    return null;
  }
}

let _refreshTimeout = null;
function scheduleRefresh(expires_in_seconds, refresh_token) {
  if (_refreshTimeout) clearTimeout(_refreshTimeout);
  const ms = Math.max((expires_in_seconds - 60) * 1000, 30 * 1000);
  _refreshTimeout = setTimeout(() => {
    refreshAccessToken().catch(err => console.error('Falha no auto-refresh', err));
  }, ms);
}

async function getAccessToken() {
  const stored = JSON.parse(sessionStorage.getItem('sp_token') || '{}');
  if (!stored.access_token) return null;
  const now = Date.now();
  if (stored.expires_at && stored.expires_at - now < 65 * 1000) {
    await refreshAccessToken();
    const fresh = JSON.parse(sessionStorage.getItem('sp_token') || '{}');
    return fresh.access_token;
  }
  return stored.access_token;
}

function initSpotifyAuthFromStorage() {
  const stored = JSON.parse(sessionStorage.getItem('sp_token') || '{}');
  if (stored && stored.expires_at) {
    const expires_in = Math.max((stored.expires_at - Date.now()) / 1000, 30);
    scheduleRefresh(expires_in, stored.refresh_token);
  }
}

function disconnectSpotify() {
  // limpa tokens e cancela refresh agendado
  sessionStorage.removeItem('sp_token');
  sessionStorage.removeItem('sp_code_verifier');
  sessionStorage.removeItem('sp_auth_state');
  if (_refreshTimeout) {
    clearTimeout(_refreshTimeout);
    _refreshTimeout = null;
  }
  updateSpotifyButton();
}

function updateSpotifyButton() {
  try {
    const btn = document.getElementById('connectSpotifyBtn');
    const stored = JSON.parse(sessionStorage.getItem('sp_token') || '{}');
    const sidebarBtn = document.getElementById('disconnectSpotifyBtn');
    if (!btn) return;
    if (stored && stored.access_token) {
      btn.textContent = 'Spotify: Conectado';
      btn.classList.add('connected');
      // altera ação para desconectar
      btn.onclick = () => disconnectSpotify();
      // mostrar botão de desconexão na sidebar, se existir
      if (sidebarBtn) {
        sidebarBtn.parentElement.classList.remove('hidden');
        sidebarBtn.onclick = () => disconnectSpotify();
      }
    } else {
      btn.textContent = 'Conectar Spotify';
      btn.classList.remove('connected');
      btn.onclick = () => startSpotifyAuth();
      // esconder botão de desconexão na sidebar
      if (sidebarBtn) {
        sidebarBtn.parentElement.classList.add('hidden');
      }
    }
  } catch (e) {
    console.warn('Erro em updateSpotifyButton', e);
  }
}

// expose api
window.spotifyAuth = { startSpotifyAuth, exchangeCodeForToken, refreshAccessToken, getAccessToken, initSpotifyAuthFromStorage, disconnectSpotify, updateSpotifyButton };

// --- Funções auxiliares do Spotify para playlists e perfil ---
async function getCurrentUserProfile() {
  try {
    const token = await getAccessToken();
    if (!token) return null;
    const res = await fetch('https://api.spotify.com/v1/me', { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) return null;
    return await res.json();
  } catch (err) {
    console.error('Erro ao obter perfil do usuário', err);
    return null;
  }
}

async function getUserPlaylists(limit = 20, offset = 0) {
  try {
    const token = await getAccessToken();
    if (!token) return [];
    const url = `https://api.spotify.com/v1/me/playlists?limit=${limit}&offset=${offset}`;
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) return [];
    const data = await res.json();
    return data.items || [];
  } catch (err) {
    console.error('Erro ao obter playlists do usuário', err);
    return [];
  }
}

async function createPlaylist(name, isPublic = false, description = '') {
  try {
    const token = await getAccessToken();
    if (!token) throw new Error('No token');
    const profile = await getCurrentUserProfile();
    if (!profile || !profile.id) throw new Error('Unable to get profile');
    const url = `https://api.spotify.com/v1/users/${profile.id}/playlists`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, public: isPublic, description })
    });
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`createPlaylist failed: ${res.status} ${txt}`);
    }
    return await res.json();
  } catch (err) {
    console.error('Erro ao criar playlist', err);
    return null;
  }
}

async function addTracksToPlaylist(playlistId, trackUris = []) {
  try {
    if (!playlistId || !trackUris || trackUris.length === 0) return null;
    const token = await getAccessToken();
    if (!token) throw new Error('No token');
    const url = `https://api.spotify.com/v1/playlists/${playlistId}/tracks`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ uris: trackUris })
    });
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`addTracksToPlaylist failed: ${res.status} ${txt}`);
    }
    return await res.json();
  } catch (err) {
    console.error('Erro ao adicionar faixas à playlist', err);
    return null;
  }
}

// Garante que exista uma playlist chamada 'MyMusic — Salvas' e retorna o id
async function ensureMyMusicPlaylist() {
  try {
    const cached = sessionStorage.getItem('sp_myplaylist_id');
    if (cached) return cached;
    const items = await getUserPlaylists(50);
    const found = items.find(p => p.name === 'MyMusic — Salvas');
    if (found) {
      sessionStorage.setItem('sp_myplaylist_id', found.id);
      return found.id;
    }
    const created = await createPlaylist('MyMusic — Salvas', false, 'Faixas salvas via MyMusic');
    if (created && created.id) {
      sessionStorage.setItem('sp_myplaylist_id', created.id);
      return created.id;
    }
    return null;
  } catch (err) {
    console.error('Erro em ensureMyMusicPlaylist', err);
    return null;
  }
}

async function addTrackToMyMusicPlaylist(trackUri) {
  try {
    if (!trackUri) throw new Error('trackUri required');
    const pid = await ensureMyMusicPlaylist();
    if (!pid) throw new Error('No playlist id');
    const res = await addTracksToPlaylist(pid, [trackUri]);
    return res;
  } catch (err) {
    console.error('Erro ao adicionar faixa à playlist MyMusic', err);
    return null;
  }
}

// expose the new helpers
window.spotifyAuth.getCurrentUserProfile = getCurrentUserProfile;
window.spotifyAuth.getUserPlaylists = getUserPlaylists;
window.spotifyAuth.createPlaylist = createPlaylist;
window.spotifyAuth.addTracksToPlaylist = addTracksToPlaylist;
window.spotifyAuth.addTrackToMyMusicPlaylist = addTrackToMyMusicPlaylist;
