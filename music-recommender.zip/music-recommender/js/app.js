let playlist = [];
let searchResults = [];
const RESULTS_PAGE_SIZE = 6;

// --- TROCA DE SEÇÕES ---
function showSection(section) {
  document.querySelectorAll("main section").forEach(sec => sec.classList.add("hidden"));
  document.getElementById(`${section}-section`).classList.remove("hidden");
  if (section === "playlist") renderPlaylist();
  if (section === "home") loadHomeRecommendations();
}

// --- RECOMENDAÇÕES ALEATÓRIAS ---
async function loadHomeRecommendations() {
  const artists = ["Coldplay", "Beyoncé", "Imagine Dragons", "Adele", "Muse"];
  const random = artists[Math.floor(Math.random() * artists.length)];
  const homeDiv = document.getElementById("home-recommendations");
  // mostrar skeletons enquanto carrega
  homeDiv.innerHTML = Array.from({length: 6}).map(() => `
    <div class="artist-card skeleton-card skeleton">
      <div class="skeleton-title"></div>
      <div class="skeleton-subtitle"></div>
      <div class="skeleton-btn"></div>
    </div>
  `).join('');
  const recommendations = await getRecommendationsData(random);

  if (!recommendations || recommendations.length === 0) {
    homeDiv.innerHTML = '<p>Nenhuma recomendação disponível.</p>';
    return;
  }

  homeDiv.innerHTML = recommendations.slice(0,6).map((a, i) => {
    const nameEnc = encodeURIComponent(a.name || '');
    const artistEnc = encodeURIComponent(a.artist || '');
    const previewEnc = encodeURIComponent(a.preview || '');
    const img = a.image || '';
    return `
    <div class="artist-card" style="opacity:0">
      ${img ? `<img class="cover" src="${img}" alt="cover">` : ''}
      <h3>${a.name}</h3>
      <p>Artista: ${a.artist}</p>
      ${a.albumType ? `<p>Tipo: ${a.albumType}</p>` : ''}
      ${a.preview ? `<audio controls src="${a.preview}"></audio>` : ''}
      <button onclick="addToPlaylist(decodeURIComponent('${nameEnc}'), decodeURIComponent('${artistEnc}'), decodeURIComponent('${previewEnc}'))">Adicionar à Playlist</button>
      ${a.uri ? `<button onclick="saveTrackToSpotify(decodeURIComponent('${encodeURIComponent(a.uri)}'))">Salvar no Spotify</button>` : ''}
    </div>
  `;
  }).join('');

  const cardsHome = homeDiv.querySelectorAll('.artist-card');
  cardsHome.forEach((c, i) => {
    c.classList.add('fade-in');
    c.style.animationDelay = `${i * 80}ms`;
  });
}

// --- RECOMENDAÇÃO PERSONALIZADA ---
async function getRecommendations() {
  const artistInput = document.getElementById('artistInput').value;
  if (!artistInput) return alert('Digite um artista!');
  const resultsDiv = document.getElementById('results');
  // inserir skeletons (imitação realista: título + subtítulo + botão)
  resultsDiv.innerHTML = Array.from({length: 6}).map(() => `
    <div class="artist-card skeleton-card skeleton">
      <div class="skeleton-title"></div>
      <div class="skeleton-subtitle"></div>
      <div class="skeleton-btn"></div>
    </div>
  `).join('');

  const recommendations = await getRecommendationsData(artistInput);
  // salvar resultados globais para paginação
  searchResults = recommendations || [];
  window._resultsShown = 0;

  if (!searchResults || searchResults.length === 0) {
    resultsDiv.innerHTML = '<p>Nenhum artista encontrado. Tente outro nome.</p>';
    return;
  }

  // renderizar primeira página
  renderResultsPage();
}

// Renderiza uma página incremental de resultados (usar RESULTS_PAGE_SIZE)
function renderResultsPage() {
  const resultsDiv = document.getElementById('results');
  const start = window._resultsShown || 0;
  const end = Math.min(start + RESULTS_PAGE_SIZE, searchResults.length);

  // montar HTML apenas dos novos itens (append incremental)
  const newItems = searchResults.slice(start, end);
  const html = newItems.map((track) => {
    const nameEnc = encodeURIComponent(track.name || '');
    const artistEnc = encodeURIComponent(track.artist || '');
    const previewEnc = encodeURIComponent(track.preview || '');
    const img = track.image || '';
    return `
    <div class="artist-card" style="opacity:0">
      ${img ? `<img class="cover" src="${img}" alt="cover">` : ''}
      <h3>${track.name}</h3>
      <p>Artista: ${track.artist}</p>
      ${track.albumType ? `<p>Tipo: ${track.albumType}</p>` : ''}
      ${track.preview ? `<audio controls src="${track.preview}"></audio>` : ''}
        <button onclick="addToPlaylist(decodeURIComponent('${nameEnc}'), decodeURIComponent('${artistEnc}'), decodeURIComponent('${previewEnc}'))">➕ Adicionar à Playlist</button>
        ${track.uri ? `<button onclick="saveTrackToSpotify(decodeURIComponent('${encodeURIComponent(track.uri)}'))">💾 Salvar no Spotify</button>` : ''}
    </div>
  `;
  }).join('');

  if (start === 0) {
    // primeira página: substituir conteúdo
    resultsDiv.innerHTML = html;
  } else {
    // remover botão anterior (se existir) antes de inserir
    const oldBtnWrap = resultsDiv.querySelector('.show-more');
    if (oldBtnWrap) oldBtnWrap.remove();
    resultsDiv.insertAdjacentHTML('beforeend', html);
  }

  // atualizar contador de itens mostrados
  window._resultsShown = end;

  // atualizar controls (contador + botão Mostrar mais)
  let controls = document.getElementById('results-controls');
  if (!controls) {
    controls = document.createElement('div');
    controls.id = 'results-controls';
    resultsDiv.parentNode.insertBefore(controls, resultsDiv.nextSibling);
  }
  // mostrar quantos são exibidos
  controls.innerHTML = `
    <div class="results-info">Mostrando ${window._resultsShown} de ${searchResults.length}</div>
  `;
  if (window._resultsShown < searchResults.length) {
    controls.insertAdjacentHTML('beforeend', `
      <div class="show-more"><button id="showMoreBtn">Mostrar mais</button></div>
    `);
    const btn = document.getElementById('showMoreBtn');
    btn.onclick = () => {
      renderResultsPage();
    };
  }

  // aplicar fade-in apenas nos itens recém-adicionados
  const cards = resultsDiv.querySelectorAll('.artist-card');
  const appended = Array.from(cards).slice(start, window._resultsShown);
  appended.forEach((c, i) => {
    c.classList.add('fade-in');
    c.style.animationDelay = `${(start + i) * 80}ms`;
  });
}

// --- PLAYLIST ---
function addToPlaylist(name, artist, preview) {
  const user = sessionStorage.getItem('loggedUser');
  if (!user) return alert('Você precisa estar logado para adicionar à playlist.');
  const stored = JSON.parse(localStorage.getItem(`playlist_${user}`)) || [];
  stored.push({ name, artist, preview });
  localStorage.setItem(`playlist_${user}`, JSON.stringify(stored));
  playlist = stored;
  renderPlaylist();
}

function renderPlaylist() {
  const user = sessionStorage.getItem('loggedUser');
  playlist = JSON.parse(localStorage.getItem(`playlist_${user}`)) || [];
  const playlistDiv = document.getElementById('playlist');

  if (playlist.length === 0) {
    playlistDiv.innerHTML = '<p>Sua playlist está vazia.</p>';
    return;
  }

  playlistDiv.innerHTML = playlist.map((song, i) => `
    <div class="playlist-item">
      <h4>${song.name} — ${song.artist}</h4>
      <button onclick="removeFromPlaylist(${i})">❌ Remover</button>
    </div>
  `).join('');
}

// Salva uma faixa na playlist 'MyMusic — Salvas' do usuário no Spotify
async function saveTrackToSpotify(uri) {
  try {
    if (!window.spotifyAuth || typeof window.spotifyAuth.addTrackToMyMusicPlaylist !== 'function') {
      return alert('Integração Spotify não disponível. Conecte o Spotify primeiro.');
    }
    const res = await window.spotifyAuth.addTrackToMyMusicPlaylist(uri);
    if (res) {
      alert('Faixa adicionada à sua playlist do Spotify com sucesso!');
    } else {
      alert('Não foi possível adicionar a faixa ao Spotify. Verifique o console.');
    }
  } catch (err) {
    console.error('saveTrackToSpotify error', err);
    alert('Erro ao salvar no Spotify. Veja o console.');
  }
}

// Carrega e renderiza as playlists do usuário (Spotify) na sidebar
async function loadSpotifyPlaylists() {
  try {
    if (!window.spotifyAuth || typeof window.spotifyAuth.getUserPlaylists !== 'function') {
      return alert('Integração Spotify não disponível. Conecte o Spotify primeiro.');
    }
    const container = document.getElementById('spotify-playlists');
    container.innerHTML = '<p>Carregando playlists do Spotify...</p>';
    container.classList.remove('hidden');
    const items = await window.spotifyAuth.getUserPlaylists(50);
    if (!items || items.length === 0) {
      container.innerHTML = '<p>Nenhuma playlist encontrada no Spotify.</p>';
      return;
    }
    container.innerHTML = items.map(p => `
      <div class="artist-card" style="margin-bottom:8px">
        <strong>${p.name}</strong>
        <div style="font-size:0.9rem;color:rgba(255,255,255,0.85)">Faixas: ${p.tracks ? p.tracks.total : '?'}</div>
        ${p.external_urls && p.external_urls.spotify ? `<a href="${p.external_urls.spotify}" target="_blank">Abrir no Spotify</a>` : ''}
      </div>
    `).join('');
  } catch (err) {
    console.error('loadSpotifyPlaylists error', err);
    alert('Erro ao carregar playlists do Spotify. Veja o console.');
  }
}

function removeFromPlaylist(index) {
  const user = sessionStorage.getItem('loggedUser');
  if (!user) return alert('Nenhum usuário logado.');
  const stored = JSON.parse(localStorage.getItem(`playlist_${user}`)) || [];
  stored.splice(index, 1);
  localStorage.setItem(`playlist_${user}`, JSON.stringify(stored));
  renderPlaylist();
}

function toggleForms(type) {
  // Ensure auth section is visible when toggling forms
  const authSection = document.getElementById('auth-section');
  if (authSection) authSection.classList.remove('hidden');
  // hide other main sections
  document.querySelectorAll("main section").forEach(sec => {
    if (sec.id !== 'auth-section') sec.classList.add('hidden');
  });
  // hide sidebar when showing auth
  const sidebar = document.getElementById('sidebar');
  if (sidebar) sidebar.classList.add('hidden');

  document.getElementById("login-form").classList.toggle("hidden", type !== "login");
  document.getElementById("register-form").classList.toggle("hidden", type !== "register");
}

// Ensure header buttons have working handlers (useful after re-showing them)
function setupHeaderButtons() {
  const lb = document.getElementById('loginBtn');
  const rb = document.getElementById('registerBtn');
  if (lb) {
    lb.onclick = () => toggleForms('login');
    lb.style.pointerEvents = 'auto';
  }
  if (rb) {
    rb.onclick = () => toggleForms('register');
    rb.style.pointerEvents = 'auto';
  }
}

window.onload = () => {
  const loggedUser = sessionStorage.getItem("loggedUser");
  if (loggedUser) {
    document.getElementById("auth-section").classList.add("hidden");
    document.getElementById("sidebar").classList.remove("hidden");
    document.getElementById("logoutBtn").classList.remove("hidden");
    // esconder botões de login/registro
    const lb = document.getElementById('loginBtn');
    const rb = document.getElementById('registerBtn');
    if (lb) lb.classList.add('hidden');
    if (rb) rb.classList.add('hidden');
    // ajustar main
    const main = document.querySelector('main');
    if (main) main.classList.remove('no-sidebar');
    showSection("home");
  } else {
    document.getElementById("sidebar").classList.add("hidden");
    const main = document.querySelector('main');
    if (main) main.classList.add('no-sidebar');
  }
  // attach header handlers on load
  if (typeof setupHeaderButtons === 'function') setupHeaderButtons();
  // attach spotify playlists loader button
  const loadBtn = document.getElementById('loadSpotifyPlaylistsBtn');
  if (loadBtn) loadBtn.onclick = () => loadSpotifyPlaylists();
  // Spotify PKCE: handle redirect exchange (if present) and resume scheduled refresh
  if (window.spotifyAuth && typeof window.spotifyAuth.exchangeCodeForToken === 'function') {
    // try exchange (if ?code= in URL)
    window.spotifyAuth.exchangeCodeForToken().then(res => {
      if (res) {
        console.log('Spotify tokens acquired via redirect.');
      }
    }).catch(err => console.warn('spotify exchange error', err));
    // resume refresh if token exists
    if (typeof window.spotifyAuth.initSpotifyAuthFromStorage === 'function') {
      window.spotifyAuth.initSpotifyAuthFromStorage();
    }
    if (typeof window.spotifyAuth.updateSpotifyButton === 'function') {
      window.spotifyAuth.updateSpotifyButton();
    }
  }
};

