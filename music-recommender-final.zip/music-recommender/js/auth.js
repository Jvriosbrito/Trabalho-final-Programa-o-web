function register() {
  const user = document.getElementById('regUser').value.trim();
  const pass = document.getElementById('regPass').value.trim();

  if (!user || !pass) return alert('Preencha todos os campos!');

  const users = JSON.parse(localStorage.getItem('users')) || {};
  if (users[user]) return alert('Usuário já cadastrado!');

  users[user] = btoa(pass);
  localStorage.setItem('users', JSON.stringify(users));

  alert('Cadastro realizado com sucesso!');
  document.getElementById('register-form').classList.add('hidden');
  document.getElementById('login-form').classList.remove('hidden');
}

function login() {
  const user = document.getElementById('loginUser').value.trim();
  const pass = document.getElementById('loginPass').value.trim();
  const users = JSON.parse(localStorage.getItem('users')) || {};

  if (users[user] && atob(users[user]) === pass) {
    alert(`Bem-vindo, ${user}!`);
    sessionStorage.setItem('loggedUser', user);

    // Integração com o layout atual: mostrar sidebar e seção inicial
    document.getElementById('auth-section').classList.add('hidden');
    document.getElementById('sidebar').classList.remove('hidden');
    document.getElementById('logoutBtn').classList.remove('hidden');
    // esconder botões de login/registro quando logado
    const lb = document.getElementById('loginBtn');
    const rb = document.getElementById('registerBtn');
    if (lb) lb.classList.add('hidden');
    if (rb) rb.classList.add('hidden');
    // ajustar margem do main (remover espaço da sidebar)
    const main = document.querySelector('main');
    if (main) main.classList.remove('no-sidebar');
    if (typeof showSection === 'function') showSection('home');
  } else {
    alert('Usuário ou senha incorretos!');
  }
}

// Função pública de logout (index.html chama onclick="logout()")
function logout() {
  sessionStorage.removeItem('loggedUser');
  document.getElementById('sidebar').classList.add('hidden');
  document.getElementById('auth-section').classList.remove('hidden');
  document.getElementById('logoutBtn').classList.add('hidden');
  // mostrar botões de login/registro novamente
  const lb = document.getElementById('loginBtn');
  const rb = document.getElementById('registerBtn');
  if (lb) lb.classList.remove('hidden');
  if (rb) rb.classList.remove('hidden');
  // re-attach header handlers in case they were removed
  if (typeof setupHeaderButtons === 'function') setupHeaderButtons();
  // ajustar margem do main para ocupar toda a largura
  const main = document.querySelector('main');
  if (main) main.classList.add('no-sidebar');
  // opcional: mostrar página inicial de auth
  if (typeof showSection === 'function') showSection('home');
}

// NOTA: os botões de alternância (login/register) no HTML já chamam toggleForms();
// não sobrescrevemos handlers inline para evitar conflitos.
