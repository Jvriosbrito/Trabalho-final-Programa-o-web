let playlist = [];
let searchResults = [];
const RESULTS_PAGE_SIZE = 6;

// --- TROCA DE SEÇÕES ---
function showSection(section) {
  document.querySelectorAll("main section").forEach(sec => sec.classList.add("hidden"));
  document.getElementById(`${section}-section`).classList.remove("hidden");
  if (section === "playlist") renderPlaylist();
  if (section === "home") loadHomeRecommendations();
}

// --- RECOMENDAÇÕES ALEATÓRIAS ---
async function loadHomeRecommendations() {
  const homeDiv = document.getElementById("home-recommendations");
  
  // Lista de estilos/artistas variados por gênero
  const genres = [
    { name: "Sertanejo", artists: ["Zé Neto & Cristiano", "Matogrosso & Mathias", "Henrique & Juliano"] },
    { name: "Pop", artists: ["Anitta", "Ivete Sangalo", "Ludmilla"] },
    { name: "MPB", artists: ["Tom Jobim", "Gilberto Gil", "Caetano Veloso"] },
    { name: "Funk", artists: ["Anitta", "Ludmilla", "MC Zaac"] },
    { name: "Rock", artists: ["Legião Urbana", "Paralamas do Sucesso", "O Terno"] },
    { name: "Forró", artists: ["Luiz Gonzaga", "Calcinha Preta", "Banda do Recife"] },
    { name: "Axé", artists: ["Ivete Sangalo", "Gal Costa", "Timbalada"] },
  ];
  
  console.log('🎵 Carregando recomendações por gênero...');
  
  // mostrar skeletons enquanto carrega
  homeDiv.innerHTML = Array.from({length: 8}).map((_, idx) => {
    if (idx === 7) {
      return `
        <div class="skeleton-section">
          <div class="skeleton-title"></div>
          <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px;">
            ${Array.from({length: 5}).map(() => `
              <div class="artist-card skeleton-card skeleton" style="width: 100%;">
                <div class="skeleton-title"></div>
                <div class="skeleton-subtitle"></div>
              </div>
            `).join('')}
          </div>
        </div>
      `;
    }
    return `
      <div class="skeleton-section">
        <div class="skeleton-title"></div>
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); gap: 12px;">
          ${Array.from({length: 10}).map(() => `
            <div class="artist-card skeleton-card skeleton" style="width: 100%;">
              <div class="skeleton-title"></div>
              <div class="skeleton-subtitle"></div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }).join('');
  
  try {
    // Carregar recomendações de cada gênero em paralelo
    const promises = genres.map(async (genre) => {
      const randomArtist = genre.artists[Math.floor(Math.random() * genre.artists.length)];
      console.log(`🎸 Buscando ${genre.name}: "${randomArtist}"`);
      const data = await getRecommendationsData(randomArtist);
      return { genre: genre.name, data: data || [] };
    });
    
    const results = await Promise.all(promises);
    
    // Montar HTML com seções por gênero
    let html = results.map(result => {
      if (!result.data || result.data.length === 0) return '';
      
      // Pegar 10 ou mais músicas de cada gênero
      const tracks = result.data.slice(0, Math.max(10, result.data.length));
      
      const tracksHTML = tracks.map((track, idx) => {
        const nameEnc = encodeURIComponent(track.name || '');
        const artistEnc = encodeURIComponent(track.artist || '');
        const previewEnc = encodeURIComponent(track.preview || '');
        const img = track.image || '';
        
        return `
          <div class="artist-card" style="opacity:0;">
            ${img ? `<img class="cover" src="${img}" alt="cover">` : ''}
            <h3>${track.name}</h3>
            <p>Artista: ${track.artist}</p>
            ${track.preview ? `<audio controls src="${track.preview}" style="width: 100%; height: 20px;"></audio>` : ''}
            <button onclick="addToPlaylist(decodeURIComponent('${nameEnc}'), decodeURIComponent('${artistEnc}'), decodeURIComponent('${previewEnc}'))">Adicionar à Playlist</button>
            ${track.uri ? `<button onclick="saveTrackToSpotify(decodeURIComponent('${encodeURIComponent(track.uri)}'))">Salvar no Spotify</button>` : ''}
          </div>
        `;
      }).join('');
      
      return `
        <div class="genre-section">
          <h2 class="genre-title">${result.genre}</h2>
          <div class="genre-grid">
            ${tracksHTML}
          </div>
        </div>
      `;
    }).join('');

    // Adicionar seção de Playlists do Spotify
    console.log('📋 Carregando playlists do Spotify...');
    const playlists = await loadSpotifyPlaylistsForHome();
    
    if (playlists && playlists.length > 0) {
      const playlistsHTML = playlists.map(p => {
        const imageUrl = p.images && p.images.length > 0 ? p.images[0].url : '';
        const spotifyUrl = p.external_urls && p.external_urls.spotify ? p.external_urls.spotify : '#';
        
        return `
          <div class="artist-card playlist-card" style="opacity:0;">
            ${imageUrl ? `<img class="cover" src="${imageUrl}" alt="playlist">` : '<div class="no-image">📋</div>'}
            <h3>${p.name}</h3>
            <p>Faixas: ${p.tracks && p.tracks.total ? p.tracks.total : '?'}</p>
            ${p.owner && p.owner.display_name ? `<p style="font-size:0.75rem; color:rgba(255,255,255,0.7);">Por: ${p.owner.display_name}</p>` : ''}
            <a href="${spotifyUrl}" target="_blank" rel="noopener noreferrer" style="display: block; text-align: center; color: var(--branco); background: rgba(29,185,84,0.7); padding: 8px; border-radius: 6px; text-decoration: none; font-size: 0.9rem; margin-top: 8px;">Abrir no Spotify</a>
          </div>
        `;
      }).join('');
      
      html += `
        <div class="genre-section">
          <h2 class="genre-title">Minhas Playlists</h2>
          <div class="genre-grid">
            ${playlistsHTML}
          </div>
        </div>
      `;
    }

    if (!html || html.trim() === '') {
      homeDiv.innerHTML = '<p>Nenhuma recomendação disponível. Tente se conectar ao Spotify!</p>';
      return;
    }

    homeDiv.innerHTML = html;
    
    // Aplicar animação fade-in em todos os cards
    const cards = homeDiv.querySelectorAll('.artist-card');
    cards.forEach((c, i) => {
      c.classList.add('fade-in');
      c.style.animationDelay = `${(i % 10) * 40}ms`;
    });
  } catch (err) {
    console.error('Erro ao carregar recomendações:', err);
    homeDiv.innerHTML = '<p>Erro ao carregar recomendações. Tente novamente.</p>';
  }
}

// Carrega playlists do Spotify para exibição na página inicial
async function loadSpotifyPlaylistsForHome() {
  try {
    if (!window.spotifyAuth || typeof window.spotifyAuth.getAccessToken !== 'function') {
      console.warn('Spotify não disponível para carregar playlists públicas');
      return [];
    }

    const token = await window.spotifyAuth.getAccessToken();
    if (!token) {
      console.log('Sem token de Spotify, pulando playlists públicas');
      return [];
    }

    console.log('📋 Buscando playlists públicas (featured + toplists) no Spotify...');

    const headers = { Authorization: `Bearer ${token}` };
    const results = [];

    // 1) Featured playlists (curated by Spotify)
    try {
      const f = await fetch('https://api.spotify.com/v1/browse/featured-playlists?limit=12', { headers });
      if (f.ok) {
        const fd = await f.json();
        const items = (fd.playlists && fd.playlists.items) ? fd.playlists.items : [];
        console.log('📋 Featured playlists carregadas:', items.length);
        results.push(...items);
      } else {
        console.warn('Featured playlists falharam:', f.status);
      }
    } catch (e) {
      console.warn('Erro ao buscar featured playlists', e);
    }

    // 2) Toplists category (popular lists)
    try {
      const t = await fetch('https://api.spotify.com/v1/browse/categories/toplists/playlists?limit=12', { headers });
      if (t.ok) {
        const td = await t.json();
        const items = (td.playlists && td.playlists.items) ? td.playlists.items : [];
        console.log('📋 Toplists playlists carregadas:', items.length);
        results.push(...items);
      } else {
        console.warn('Toplists category falhou:', t.status);
      }
    } catch (e) {
      console.warn('Erro ao buscar toplists playlists', e);
    }

    // Deduplicar por id
    const byId = {};
    results.forEach(p => { if (p && p.id) byId[p.id] = p; });
    const unique = Object.values(byId).slice(0, 12);
    console.log('📋 Playlists públicas finais (únicas):', unique.length);
    return unique;
  } catch (err) {
    console.error('Erro ao carregar playlists públicas para homepage:', err);
    return [];
  }
}

// --- RECOMENDAÇÃO PERSONALIZADA ---
async function getRecommendations() {
  const artistInput = document.getElementById('artistInput').value;
  if (!artistInput) return alert('Digite um artista!');
  const resultsDiv = document.getElementById('results');
  // inserir skeletons (imitação realista: título + subtítulo + botão)
  resultsDiv.innerHTML = Array.from({length: 6}).map(() => `
    <div class="artist-card skeleton-card skeleton">
      <div class="skeleton-title"></div>
      <div class="skeleton-subtitle"></div>
      <div class="skeleton-btn"></div>
    </div>
  `).join('');

  const recommendations = await getRecommendationsData(artistInput);
  // salvar resultados globais para paginação
  searchResults = recommendations || [];
  window._resultsShown = 0;

  if (!searchResults || searchResults.length === 0) {
    resultsDiv.innerHTML = '<p>Nenhum artista encontrado. Tente outro nome.</p>';
    return;
  }

  // renderizar primeira página
  renderResultsPage();
}

// Renderiza uma página incremental de resultados (usar RESULTS_PAGE_SIZE)
function renderResultsPage() {
  const resultsDiv = document.getElementById('results');
  const start = window._resultsShown || 0;
  const end = Math.min(start + RESULTS_PAGE_SIZE, searchResults.length);

  // montar HTML apenas dos novos itens (append incremental)
  const newItems = searchResults.slice(start, end);
  const html = newItems.map((track) => {
    const nameEnc = encodeURIComponent(track.name || '');
    const artistEnc = encodeURIComponent(track.artist || '');
    const previewEnc = encodeURIComponent(track.preview || '');
    const img = track.image || '';
    return `
    <div class="artist-card" style="opacity:0">
      ${img ? `<img class="cover" src="${img}" alt="cover">` : ''}
      <h3>${track.name}</h3>
      <p>Artista: ${track.artist}</p>
      ${track.albumType ? `<p>Tipo: ${track.albumType}</p>` : ''}
      ${track.preview ? `<audio controls src="${track.preview}"></audio>` : ''}
        <button onclick="addToPlaylist(decodeURIComponent('${nameEnc}'), decodeURIComponent('${artistEnc}'), decodeURIComponent('${previewEnc}'))">Adicionar à Playlist</button>
        ${track.uri ? `<button onclick="saveTrackToSpotify(decodeURIComponent('${encodeURIComponent(track.uri)}'))">Salvar no Spotify</button>` : ''}
    </div>
  `;
  }).join('');

  if (start === 0) {
    // primeira página: substituir conteúdo
    resultsDiv.innerHTML = html;
  } else {
    // remover botão anterior (se existir) antes de inserir
    const oldBtnWrap = resultsDiv.querySelector('.show-more');
    if (oldBtnWrap) oldBtnWrap.remove();
    resultsDiv.insertAdjacentHTML('beforeend', html);
  }

  // atualizar contador de itens mostrados
  window._resultsShown = end;

  // atualizar controls (contador + botão Mostrar mais)
  let controls = document.getElementById('results-controls');
  if (!controls) {
    controls = document.createElement('div');
    controls.id = 'results-controls';
    resultsDiv.parentNode.insertBefore(controls, resultsDiv.nextSibling);
  }
  // mostrar quantos são exibidos
  controls.innerHTML = `
    <div class="results-info">Mostrando ${window._resultsShown} de ${searchResults.length}</div>
  `;
  if (window._resultsShown < searchResults.length) {
    controls.insertAdjacentHTML('beforeend', `
      <div class="show-more"><button id="showMoreBtn">Mostrar mais</button></div>
    `);
    const btn = document.getElementById('showMoreBtn');
    btn.onclick = () => {
      renderResultsPage();
    };
  }

  // aplicar fade-in apenas nos itens recém-adicionados
  const cards = resultsDiv.querySelectorAll('.artist-card');
  const appended = Array.from(cards).slice(start, window._resultsShown);
  appended.forEach((c, i) => {
    c.classList.add('fade-in');
    c.style.animationDelay = `${(start + i) * 80}ms`;
  });
}

// --- PLAYLIST ---
function addToPlaylist(name, artist, preview) {
  const user = sessionStorage.getItem('loggedUser');
  if (!user) return alert('Você precisa estar logado para adicionar à playlist.');
  const stored = JSON.parse(localStorage.getItem(`playlist_${user}`)) || [];
  stored.push({ name, artist, preview });
  localStorage.setItem(`playlist_${user}`, JSON.stringify(stored));
  playlist = stored;
  renderPlaylist();
}

function renderPlaylist() {
  const user = sessionStorage.getItem('loggedUser');
  playlist = JSON.parse(localStorage.getItem(`playlist_${user}`)) || [];
  const playlistDiv = document.getElementById('playlist');

  if (playlist.length === 0) {
    playlistDiv.innerHTML = '<p>Sua playlist está vazia.</p>';
    return;
  }

  playlistDiv.innerHTML = playlist.map((song, i) => `
    <div class="playlist-item">
      <h4>${song.name} — ${song.artist}</h4>
      <button onclick="removeFromPlaylist(${i})">❌ Remover</button>
    </div>
  `).join('');
}

// Salva uma faixa na playlist 'MyMusic — Salvas' do usuário no Spotify
async function saveTrackToSpotify(uri) {
  try {
    console.log('\n\n========================================');
    console.log('🎵 [saveTrackToSpotify] INICIANDO');
    console.log('URI:', uri);
    console.log('========================================\n');
    
    // Verificar se spotifyAuth está disponível
    if (!window.spotifyAuth) {
      console.error('❌ spotifyAuth não disponível');
      alert('❌ Integração Spotify não disponível!');
      return;
    }
    
    // Verificar se está conectado ao Spotify
    const token = await window.spotifyAuth.getAccessToken();
    console.log('Token:', token ? '✅ OK' : '❌ NULO');
    if (!token) {
      alert('⚠️ Você precisa estar conectado ao Spotify para salvar uma música!');
      return;
    }
    
    // Verificar se a função existe
    if (typeof window.spotifyAuth.addTrackToMyMusicPlaylist !== 'function') {
      console.error('❌ addTrackToMyMusicPlaylist não é function');
      return alert('❌ Função não disponível. Conecte o Spotify primeiro.');
    }
    
    console.log('✅ Tudo OK, chamando addTrackToMyMusicPlaylist...\n');
    const res = await window.spotifyAuth.addTrackToMyMusicPlaylist(uri);
    
    console.log('\n========================================');
    console.log('🎵 [saveTrackToSpotify] RESULTADO:');
    console.log('Resposta:', res);
    console.log('========================================\n');
    
    if (res) {
      alert('✅ Faixa adicionada à sua playlist do Spotify com sucesso!');
    } else {
      alert('❌ Não foi possível adicionar a faixa ao Spotify. Verifique o console.');
    }
  } catch (err) {
    console.error('❌ saveTrackToSpotify catch:', err);
    alert('❌ Erro ao salvar no Spotify. Veja o console para detalhes.');
  }
}

// Carrega e renderiza as playlists do usuário (Spotify) na sidebar
async function loadSpotifyPlaylists() {
  try {
    if (!window.spotifyAuth || typeof window.spotifyAuth.getUserPlaylists !== 'function') {
      return alert('Integração Spotify não disponível. Conecte o Spotify primeiro.');
    }
    const container = document.getElementById('spotify-playlists');
    container.innerHTML = '<p>Carregando playlists do Spotify...</p>';
    container.classList.remove('hidden');
    const items = await window.spotifyAuth.getUserPlaylists(50);
    if (!items || items.length === 0) {
      container.innerHTML = '<p>Nenhuma playlist encontrada no Spotify.</p>';
      return;
    }
    container.innerHTML = items.map(p => `
      <div class="artist-card" style="margin-bottom:8px">
        <strong>${p.name}</strong>
        <div style="font-size:0.9rem;color:rgba(255,255,255,0.85)">Faixas: ${p.tracks ? p.tracks.total : '?'}</div>
        ${p.external_urls && p.external_urls.spotify ? `<a href="${p.external_urls.spotify}" target="_blank">Abrir no Spotify</a>` : ''}
      </div>
    `).join('');
  } catch (err) {
    console.error('loadSpotifyPlaylists error', err);
    alert('Erro ao carregar playlists do Spotify. Veja o console.');
  }
}

function removeFromPlaylist(index) {
  const user = sessionStorage.getItem('loggedUser');
  if (!user) return alert('Nenhum usuário logado.');
  const stored = JSON.parse(localStorage.getItem(`playlist_${user}`)) || [];
  stored.splice(index, 1);
  localStorage.setItem(`playlist_${user}`, JSON.stringify(stored));
  renderPlaylist();
}

function toggleForms(type) {
  // Ensure auth section is visible when toggling forms
  const authSection = document.getElementById('auth-section');
  if (authSection) authSection.classList.remove('hidden');
  // hide other main sections
  document.querySelectorAll("main section").forEach(sec => {
    if (sec.id !== 'auth-section') sec.classList.add('hidden');
  });
  // hide sidebar when showing auth
  const sidebar = document.getElementById('sidebar');
  if (sidebar) sidebar.classList.add('hidden');

  document.getElementById("login-form").classList.toggle("hidden", type !== "login");
  document.getElementById("register-form").classList.toggle("hidden", type !== "register");
}

// Ensure header buttons have working handlers (useful after re-showing them)
function setupHeaderButtons() {
  const lb = document.getElementById('loginBtn');
  const rb = document.getElementById('registerBtn');
  if (lb) {
    lb.onclick = () => toggleForms('login');
    lb.style.pointerEvents = 'auto';
  }
  if (rb) {
    rb.onclick = () => toggleForms('register');
    rb.style.pointerEvents = 'auto';
  }
}

window.onload = () => {
  const loggedUser = sessionStorage.getItem("loggedUser");
  if (loggedUser) {
    document.getElementById("auth-section").classList.add("hidden");
    document.getElementById("sidebar").classList.remove("hidden");
    document.getElementById("logoutBtn").classList.remove("hidden");
    // esconder botões de login/registro
    const lb = document.getElementById('loginBtn');
    const rb = document.getElementById('registerBtn');
    if (lb) lb.classList.add('hidden');
    if (rb) rb.classList.add('hidden');
    // ajustar main
    const main = document.querySelector('main');
    if (main) main.classList.remove('no-sidebar');
    showSection("home");
  } else {
    document.getElementById("sidebar").classList.add("hidden");
    const main = document.querySelector('main');
    if (main) main.classList.add('no-sidebar');
  }
  // attach header handlers on load
  if (typeof setupHeaderButtons === 'function') setupHeaderButtons();
  // attach spotify playlists loader button
  const loadBtn = document.getElementById('loadSpotifyPlaylistsBtn');
  if (loadBtn) loadBtn.onclick = () => loadSpotifyPlaylists();
  // Spotify PKCE: handle redirect exchange (if present) and resume scheduled refresh
  if (window.spotifyAuth && typeof window.spotifyAuth.exchangeCodeForToken === 'function') {
    // try exchange (if ?code= in URL)
    window.spotifyAuth.exchangeCodeForToken().then(res => {
      if (res) {
        console.log('Spotify tokens acquired via redirect.');
      }
    }).catch(err => console.warn('spotify exchange error', err));
    // resume refresh if token exists
    if (typeof window.spotifyAuth.initSpotifyAuthFromStorage === 'function') {
      window.spotifyAuth.initSpotifyAuthFromStorage();
    }
    if (typeof window.spotifyAuth.updateSpotifyButton === 'function') {
      window.spotifyAuth.updateSpotifyButton();
    }
  }
};

