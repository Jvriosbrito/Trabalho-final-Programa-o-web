// 🔍 Busca artistas no MusicBrainz
async function getArtistData(artistName) {
  try {
    const url = `https://musicbrainz.org/ws/2/artist/?query=${artistName}&fmt=json`;
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Network response was not ok: ${response.status}`);
    const data = await response.json();
    return (data.artists || []).slice(0, 5);
  } catch (err) {
    console.error('getArtistData error:', err);
    return [];
  }
}

// --- Spotify search using PKCE-backed token (preferred) ---
async function getSpotifyTracks(artistName, limit = 12) {
  try {
    // prefer spotifyAuth helper if available
    if (!window.spotifyAuth || typeof window.spotifyAuth.getAccessToken !== 'function') {
      console.warn('spotifyAuth not available – skipping Spotify search');
      return [];
    }

    let token = await window.spotifyAuth.getAccessToken();
    if (!token) {
      console.warn('No Spotify token available – skipping Spotify search');
      return [];
    }

    const q = encodeURIComponent(artistName);
    const url = `https://api.spotify.com/v1/search?q=${q}&type=track&limit=${limit}`;
    let res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });

    if (res.status === 401) {
      // try refreshing token via spotifyAuth
      console.warn('Spotify token 401, attempting refresh...');
      if (typeof window.spotifyAuth.refreshAccessToken === 'function') {
        await window.spotifyAuth.refreshAccessToken();
        token = await window.spotifyAuth.getAccessToken();
        res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
      }
    }

    if (!res.ok) {
      console.warn('Spotify search failed', res.status);
      return [];
    }

    const data = await res.json();
    return (data.tracks && data.tracks.items) ? data.tracks.items : [];
  } catch (err) {
    console.error('getSpotifyTracks error:', err);
    return [];
  }
}async function getRecommendationsData(artistName) {
  // Try Spotify first (richer results: preview, image)
  const spotify = await getSpotifyTracks(artistName, 24);
  if (spotify && spotify.length > 0) {
    return spotify.map(track => ({
      name: track.name,
      artist: track.artists.map(a => a.name).join(', '),
      preview: track.preview_url,
      image: track.album && track.album.images ? track.album.images[0]?.url || '' : '',
      uri: track.uri // ex: spotify:track:... used to save to playlists
    }));
  }

  // fallback: use MusicBrainz simulated recommendations (existing behavior)
  const artists = await getArtistData(artistName);
  if (!artists || artists.length === 0) return [];
  const results = [];
  artists.forEach(a => {
    results.push({ name: `Best of ${a.name}`, artist: a.name, albumType: 'Compilação', preview: '', image: '' });
    results.push({ name: `${a.name} — Live`, artist: a.name, albumType: 'Ao Vivo', preview: '', image: '' });
    results.push({ name: `${a.name} — Essentials`, artist: a.name, albumType: 'Essenciais', preview: '', image: '' });
  });
  return results;
}
